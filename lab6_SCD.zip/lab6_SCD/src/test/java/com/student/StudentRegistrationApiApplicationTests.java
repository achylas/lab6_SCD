package com.student;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentRegistrationApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
